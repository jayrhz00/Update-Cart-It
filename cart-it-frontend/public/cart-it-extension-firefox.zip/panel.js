const DEFAULT_API =
  typeof CART_IT_CONFIG !== "undefined" && CART_IT_CONFIG.defaultApiBase
    ? CART_IT_CONFIG.defaultApiBase
    : "https://cart-it.onrender.com";
const FALLBACK_LOCAL_API =
  typeof CART_IT_CONFIG !== "undefined" && CART_IT_CONFIG.fallbackLocalApi
    ? CART_IT_CONFIG.fallbackLocalApi
    : "http://127.0.0.1:5001";

/** Runs in the product tab — name, price, image, store from the page. */
function getPageData() {
  const textFromScript = (selector) => {
    const el = document.querySelector(selector);
    return el?.textContent || "";
  };
  const ogImage =
    document.querySelector('meta[property="og:image"]')?.content ||
    document.querySelector('meta[name="twitter:image"]')?.content ||
    document.querySelector('link[rel="image_src"]')?.href ||
    "";
  const parsePriceText = (raw) => {
    if (!raw) return null;
    const compact = String(raw).replace(/\s+/g, "");
    const match = compact.match(/([0-9][0-9.,]*)/);
    if (!match?.[1]) return null;
    let token = match[1];
    const hasComma = token.includes(",");
    const hasDot = token.includes(".");
    if (hasComma && hasDot) {
      const lastComma = token.lastIndexOf(",");
      const lastDot = token.lastIndexOf(".");
      if (lastComma > lastDot) {
        // 1.799,99 -> 1799.99
        token = token.replace(/\./g, "").replace(",", ".");
      } else {
        // 1,799.99 -> 1799.99
        token = token.replace(/,/g, "");
      }
    } else if (hasComma) {
      // 17,99 -> 17.99 ; 1,799 -> 1799
      token = /,\d{1,2}$/.test(token) ? token.replace(",", ".") : token.replace(/,/g, "");
    }
    const parsed = Number(token);
    return Number.isFinite(parsed) && parsed >= 0 ? parsed : null;
  };

  const isAmazon = /\.amazon\./i.test(location.hostname);
  const getAmazonPrice = () => {
    const selectors = [
      "#corePriceDisplay_desktop_feature_div .a-price .a-offscreen",
      "#corePriceDisplay_mobile_feature_div .a-price .a-offscreen",
      "#corePrice_feature_div .a-price .a-offscreen",
      "#price_inside_buybox",
      "#priceblock_ourprice",
      "#priceblock_dealprice",
      "#priceblock_saleprice",
      "#reinvent_price_desktop_buybox .a-price .a-offscreen",
      "#apex_desktop .a-price .a-offscreen",
      'span[data-a-color="price"] .a-offscreen',
      ".a-price.aok-align-center .a-offscreen",
      ".a-price .a-offscreen",
    ];
    for (const sel of selectors) {
      const el = document.querySelector(sel);
      const txt = el?.textContent || el?.getAttribute?.("content") || "";
      const parsed = parsePriceText(txt);
      if (parsed != null && /\.\d{2}\b/.test(String(txt))) return parsed;
    }
    const core =
      document.querySelector("#corePriceDisplay_desktop_feature_div") ||
      document.querySelector("#corePriceDisplay_mobile_feature_div") ||
      document.querySelector("#corePrice_feature_div");
    if (core) {
      const m = (core.innerText || "").match(/\$\s*([0-9][0-9,]*\.[0-9]{2})/);
      const parsed = parsePriceText(m?.[1]);
      if (parsed != null) return parsed;
    }
    return null;
  };

  const getAmazonPriceFromBuybox = () => {
    const roots = [
      document.querySelector("#buybox"),
      document.querySelector("#desktop_buybox"),
      document.querySelector("#unifiedPrice_feature_div"),
      document.querySelector("#corePriceDisplay_desktop_feature_div"),
      document.querySelector("#corePrice_feature_div"),
      document.querySelector("#apex_desktop"),
      document.querySelector("#rightCol"),
    ].filter(Boolean);
    const amounts = [];
    for (const root of roots) {
      root.querySelectorAll(".a-offscreen").forEach((el) => {
        const t = el.textContent || "";
        if (!/\d+\.\d{2}/.test(t)) return;
        const p = parsePriceText(t);
        if (p != null && p >= 0.01 && p < 1_000_000) amounts.push(p);
      });
    }
    if (!amounts.length) return null;
    return Math.min(...amounts);
  };

  const pricesFromDollarMatches = (text) => {
    if (!text) return [];
    const matches = [...String(text).matchAll(/\$\s*([0-9][0-9,]*(?:\.[0-9]{1,2})?)/g)];
    const out = [];
    for (const m of matches) {
      const p = parsePriceText(m[1]);
      if (p != null && p >= 1 && p < 1_000_000) out.push(p);
    }
    return out;
  };

  const pricesFromDollarCentsMatches = (text) => {
    if (!text) return [];
    const matches = [...String(text).matchAll(/\$\s*([0-9][0-9,]*\.\d{2})\b/g)];
    const out = [];
    for (const m of matches) {
      const p = parsePriceText(m[1]);
      if (p != null && p >= 0.01 && p < 1_000_000) out.push(p);
    }
    return out;
  };

  const pickNearCartPriceFromText = (text) => {
    const cents = pricesFromDollarCentsMatches(text);
    if (cents.length) return Math.min(...cents);
    const loose = pricesFromDollarMatches(text);
    if (!loose.length) return null;
    return Math.min(...loose);
  };

  const priceNearPrimaryAddToCart = () => {
    const candidates = Array.from(
      document.querySelectorAll(
        [
          'button[name="add"]',
          'button[id*="AddToCart"]',
          'button[id*="addtocart"]',
          'button[class*="add-to-cart"]',
          'button[class*="AddToCart"]',
          "[data-add-to-cart]",
          'button[aria-label*="add to cart"]',
          'button[aria-label*="Add to cart"]',
          'button[aria-label*="add to bag"]',
          "[data-test*=\"addToCart\"]",
          "[data-test*=\"AddToCart\"]",
          "[data-test*=\"add-to-cart\"]",
          "[data-test=\"shippingPickupBuyButton\"]",
        ].join(",")
      )
    );
    const btn =
      candidates.find((b) => /cart|bag|checkout|buy now/i.test(b.textContent || "")) ||
      Array.from(document.querySelectorAll("button, a")).find((b) =>
        /^\s*add\s+to\s+cart\s*$/i.test((b.textContent || "").trim())
      );
    if (!btn) return null;
    let node = btn;
    for (let depth = 0; depth < 14 && node; depth++, node = node.parentElement) {
      const text = (node.innerText || "").slice(0, 2500);
      const picked = pickNearCartPriceFromText(text);
      if (picked == null) continue;
      const st = window.getComputedStyle(node);
      const fixedish = st.position === "fixed" || st.position === "sticky";
      const cls = `${node.className || ""} ${node.id || ""}`;
      if (fixedish || /sticky|bottom|bar|drawer|atc/i.test(cls)) {
        return picked;
      }
    }
    node = btn;
    for (let depth = 0; depth < 10 && node; depth++, node = node.parentElement) {
      const picked = pickNearCartPriceFromText((node.innerText || "").slice(0, 2500));
      if (picked != null) return picked;
    }
    return null;
  };

  let price = null;
  if (isAmazon) {
    price = getAmazonPrice() ?? getAmazonPriceFromBuybox();
  }
  const parseJsonPrice = (obj) => {
    if (!obj || typeof obj !== "object") return null;
    const candidates = [
      obj.price,
      obj.lowPrice,
      obj.highPrice,
      obj.minPrice,
      obj.maxPrice,
      obj?.offers?.price,
      obj?.offers?.lowPrice,
      obj?.offers?.highPrice,
    ];
    for (const c of candidates) {
      const parsed = parsePriceText(c);
      if (parsed != null) return parsed;
    }
    if (Array.isArray(obj)) {
      for (const v of obj) {
        const nested = parseJsonPrice(v);
        if (nested != null) return nested;
      }
      return null;
    }
    for (const value of Object.values(obj)) {
      if (value && typeof value === "object") {
        const nested = parseJsonPrice(value);
        if (nested != null) return nested;
      }
    }
    return null;
  };

  const parseFirstDollarCents = (raw) => {
    if (!raw) return null;
    const s = String(raw);
    const m = s.match(/\$\s*([0-9][0-9,]*\.\d{2})\b/);
    if (!m?.[1]) return null;
    return parsePriceText(m[1]);
  };

  const typesIncludeProduct = (t) => {
    if (t == null) return false;
    const checkOne = (x) => {
      const s = String(x).toLowerCase().trim();
      if (s.includes("productgroup")) return false;
      return (
        s === "product" ||
        s.endsWith("/product") ||
        s.endsWith("schema.org/product")
      );
    };
    if (Array.isArray(t)) return t.some(checkOne);
    return checkOne(t);
  };

  const priceFromOfferObject = (o) => {
    if (!o || typeof o !== "object") return null;
    const raw =
      o.price ??
      o.lowPrice ??
      o.highPrice ??
      o?.priceSpecification?.price ??
      o?.priceSpecification?.value;
    if (raw != null && typeof raw === "object") {
      const nested = parsePriceText(raw.value ?? raw.price);
      if (nested != null) return nested;
    }
    return parsePriceText(raw);
  };

  const priceFromOffers = (offers) => {
    if (!offers) return null;
    const list = Array.isArray(offers) ? offers : [offers];
    for (const o of list) {
      if (!o || typeof o !== "object") continue;
      const p = priceFromOfferObject(o);
      if (p != null && p > 0 && p < 500000) return p;
    }
    return null;
  };

  const extractJsonLdProductPrice = () => {
    const scripts = document.querySelectorAll('script[type="application/ld+json"]');
    for (const node of scripts) {
      try {
        const data = JSON.parse(node.textContent);
        const roots = Array.isArray(data) ? data : [data];
        for (const root of roots) {
          if (!root || typeof root !== "object") continue;
          if (typesIncludeProduct(root["@type"])) {
            const p = priceFromOffers(root.offers) ?? parsePriceText(root.price);
            if (p != null && p > 0 && p < 500000) return p;
          }
          if (Array.isArray(root["@graph"])) {
            for (const g of root["@graph"]) {
              if (g && typesIncludeProduct(g["@type"])) {
                const p = priceFromOffers(g.offers) ?? parsePriceText(g.price);
                if (p != null && p > 0 && p < 500000) return p;
              }
            }
          }
        }
      } catch (_) {
        /* ignore */
      }
    }
    return null;
  };

  const extractTargetDomPrice = () => {
    const candidates = [];
    const pushFromText = (t) => {
      const strict = parseFirstDollarCents(t || "");
      if (strict != null && strict > 0 && strict < 500000) candidates.push(strict);
    };
    const sels = [
      '[data-test="product-price"]',
      '[data-test="@web/ProductDetailPrice"]',
      '[data-test="@web/Price"]',
      '[data-test="product-summary-price"]',
      '[data-test="product-summary-price"] *',
      '[data-test="product-price"] *',
      '[data-test*="ProductDetailPrice"]',
      '[data-test*="product-price"]',
      '[data-test*="Price"]:not([data-test*="Compare"])',
      "h1 + div [class*='price']",
    ];
    for (const sel of sels) {
      try {
        document.querySelectorAll(sel).forEach((el) => pushFromText(el.textContent));
      } catch (_) {
        /* invalid selector in older engines */
      }
    }
    if (!candidates.length) return null;
    candidates.sort((a, b) => a - b);
    const lo = candidates[0];
    const hi = candidates[candidates.length - 1];
    if (candidates.length > 1 && hi > lo * 12 && lo < 8000 && hi >= 50) return lo;
    return lo;
  };

  const isTarget = /(^|\.)target\.com$/i.test(location.hostname);

  if (!isAmazon) {
    price = extractJsonLdProductPrice();

    if (price == null && isTarget) {
      price = extractTargetDomPrice();
    }

    if (price == null && !isTarget) {
      const metaPriceSelectors = [
        'meta[property="product:price:amount"]',
        'meta[property="og:price:amount"]',
        'meta[name="twitter:data1"]',
        'meta[itemprop="price"]',
        'meta[name="price"]',
      ];
      for (const selector of metaPriceSelectors) {
        const parsed = parsePriceText(document.querySelector(selector)?.getAttribute("content"));
        if (parsed != null) {
          price = parsed;
          break;
        }
      }
    }

    if (price == null && !isTarget) {
      const nextDataRaw = textFromScript("#__NEXT_DATA__");
      if (nextDataRaw) {
        try {
          const parsed = parseJsonPrice(JSON.parse(nextDataRaw));
          if (parsed != null) price = parsed;
        } catch (_) {
          /* ignore */
        }
      }
    }

    if (price == null) {
      const tight = Array.from(
        document.querySelectorAll(
          ['[itemprop="price"]', '[data-testid*="price"]', '[id*="product-price"]', '[id*="ProductPrice"]'].join(",")
        )
      );
      const tightAmounts = [];
      for (const el of tight) {
        const content = el.getAttribute?.("content");
        const text = content || el.textContent || "";
        const strict = parseFirstDollarCents(text);
        const loose = parsePriceText(text);
        const p = strict ?? loose;
        if (p != null && p > 0 && p < 500000) tightAmounts.push(p);
      }
      if (tightAmounts.length) {
        tightAmounts.sort((a, b) => a - b);
        price = tightAmounts[0];
      }
    }

    if (price == null) {
      const looseEls = Array.from(
        document.querySelectorAll(['[class*="price"]', '[id*="price"]'].join(","))
      );
      const amounts = [];
      for (const el of looseEls) {
        const text = el.getAttribute?.("content") || el.textContent || "";
        const strict = parseFirstDollarCents(text);
        if (strict != null) {
          amounts.push(strict);
          continue;
        }
        const loose = parsePriceText(text);
        if (loose != null && loose > 0 && loose < 500000) amounts.push(loose);
      }
      if (amounts.length) {
        amounts.sort((a, b) => a - b);
        const lo = amounts[0];
        const hi = amounts[amounts.length - 1];
        if (amounts.length > 1 && hi > lo * 25 && lo < 5000 && hi >= 200) price = lo;
        else price = amounts[Math.floor(amounts.length / 2)];
      }
    }
  }

  if (price == null && !isAmazon && !isTarget) {
    const bodyText = (document.body?.innerText || "").slice(0, 12000);
    const fallbackRegexes = [
      /(?:\$|USD\s?)([0-9]+(?:\.[0-9]{1,2})?)/i,
      /([0-9]+(?:\.[0-9]{1,2})?)\s?(?:USD|dollars?)/i,
    ];
    for (const re of fallbackRegexes) {
      const m = bodyText.match(re);
      if (m?.[1]) {
        const parsed = parsePriceText(m[1]);
        if (parsed != null) {
          price = parsed;
          break;
        }
      }
    }
  }

  const nearCartPrice = isAmazon ? null : priceNearPrimaryAddToCart();
  if (nearCartPrice != null) {
    if (price == null) price = nearCartPrice;
    else if (Math.abs(nearCartPrice - price) >= 0.5) {
      const hi = Math.max(price, nearCartPrice);
      const lo = Math.min(price, nearCartPrice);
      if (hi >= lo * 15 && lo > 0 && lo < 5000) price = lo;
      else price = nearCartPrice;
    }
  }

  if (!isAmazon && isTarget && price != null && price >= 50) {
    const repair = extractTargetDomPrice();
    if (repair != null && repair < price && price / repair >= 4 && repair < 50000) price = repair;
  }

  const detectInStock = () => {
    const bodyText = (document.body?.innerText || "").toLowerCase();
    const outPatterns = [
      "out of stock",
      "sold out",
      "currently unavailable",
      "temporarily unavailable",
      "notify me when available",
    ];
    for (const token of outPatterns) {
      if (bodyText.includes(token)) return false;
    }
    const inPatterns = ["in stock", "add to cart", "buy now", "available now"];
    for (const token of inPatterns) {
      if (bodyText.includes(token)) return true;
    }
    return true;
  };
  const host = location.hostname.replace(/^www\./, "");

  const extractJsonLdImageUrl = () => {
    const scripts = document.querySelectorAll('script[type="application/ld+json"]');
    for (const node of scripts) {
      try {
        const data = JSON.parse(node.textContent);
        const roots = Array.isArray(data) ? data : [data];
        for (const root of roots) {
          if (!root || typeof root !== "object") continue;
          const pick = (obj) => {
            if (!obj || typeof obj !== "object") return "";
            const img = obj.image;
            if (typeof img === "string" && /^https?:\/\//i.test(img)) return img.trim();
            if (Array.isArray(img) && img.length) {
              const first = img[0];
              if (typeof first === "string" && /^https?:\/\//i.test(first)) return first.trim();
              if (first && typeof first === "object")
                return String(first.url || first.contentUrl || "").trim();
            }
            if (img && typeof img === "object")
              return String(img.url || img.contentUrl || "").trim();
            return "";
          };
          if (typesIncludeProduct(root["@type"])) {
            const u = pick(root);
            if (u) return u;
          }
          if (Array.isArray(root["@graph"])) {
            for (const g of root["@graph"]) {
              if (g && typesIncludeProduct(g["@type"])) {
                const u = pick(g);
                if (u) return u;
              }
            }
          }
        }
      } catch (_) {
        /* ignore */
      }
    }
    return "";
  };

  const extractProductDescription = () => {
    const fromMeta = [
      document.querySelector('meta[property="og:description"]')?.getAttribute("content"),
      document.querySelector('meta[name="twitter:description"]')?.getAttribute("content"),
      document.querySelector('meta[name="description"]')?.getAttribute("content"),
    ];
    for (const m of fromMeta) {
      const t = String(m || "").replace(/\s+/g, " ").trim();
      if (t.length > 24) return t.slice(0, 4000);
    }
    const scripts = document.querySelectorAll('script[type="application/ld+json"]');
    for (const node of scripts) {
      try {
        const data = JSON.parse(node.textContent);
        const roots = Array.isArray(data) ? data : [data];
        for (const root of roots) {
          if (!root || typeof root !== "object") continue;
          const readDesc = (obj) => {
            if (!obj || typeof obj !== "object") return "";
            const d = obj.description;
            if (typeof d === "string") return d.replace(/\s+/g, " ").trim();
            if (Array.isArray(d) && typeof d[0] === "string") return d[0].replace(/\s+/g, " ").trim();
            return "";
          };
          if (typesIncludeProduct(root["@type"])) {
            const t = readDesc(root);
            if (t.length > 24) return t.slice(0, 4000);
          }
          if (Array.isArray(root["@graph"])) {
            for (const g of root["@graph"]) {
              if (g && typesIncludeProduct(g["@type"])) {
                const t = readDesc(g);
                if (t.length > 24) return t.slice(0, 4000);
              }
            }
          }
        }
      } catch (_) {
        /* ignore */
      }
    }
    if (/\.amazon\./i.test(location.hostname)) {
      const bullets = document.querySelector("#feature-bullets ul, #featurebullets_feature_div ul");
      if (bullets) {
        const items = [...bullets.querySelectorAll("li")].map((li) => (li.textContent || "").trim()).filter(Boolean);
        if (items.length) return items.join(" • ").slice(0, 4000);
      }
    }
    return "";
  };

  const product_description = extractProductDescription();

  let imageUrl = ogImage || "";
  if (!imageUrl.trim()) {
    const itemprop = document.querySelector('img[itemprop="image"]');
    const fromItemprop = itemprop?.src || itemprop?.getAttribute("content") || "";
    if (fromItemprop && /^https?:\/\//i.test(fromItemprop)) imageUrl = fromItemprop.trim();
  }
  if (!imageUrl.trim()) {
    const fromLd = extractJsonLdImageUrl();
    if (fromLd) imageUrl = fromLd;
  }
  if (!imageUrl.trim() && /\.amazon\./i.test(location.hostname)) {
    const landing = document.querySelector("#landingImage");
    const fromLanding =
      landing?.getAttribute("src") ||
      landing?.getAttribute("data-old-hires") ||
      landing?.currentSrc ||
      "";
    if (fromLanding) imageUrl = fromLanding;
  }
  const finalName = (
    document.querySelector('meta[property="og:title"]')?.content ||
    document.querySelector('meta[name="twitter:title"]')?.content ||
    document.querySelector("h1")?.textContent ||
    document.title ||
    "Untitled page"
  ).trim();

  const finalUrl = (
    document.querySelector('link[rel="canonical"]')?.href || location.href
  ).trim();

  return {
    item_name: finalName,
    product_url: finalUrl,
    image_url: imageUrl,
    product_description,
    store: host,
    current_price: price != null && !Number.isNaN(price) ? price : 0,
    is_in_stock: detectInStock(),
  };
}

let lastCapture = null;
let authRejected = false;
let cachedGroups = [];
let currentUserLabel = "";
let manualPriceDirty = false;

function truncate(s, max) {
  const t = String(s || "");
  return t.length <= max ? t : `${t.slice(0, max - 1)}…`;
}

async function getWebAppOrigin() {
  const fallback =
    typeof CART_IT_CONFIG !== "undefined" && CART_IT_CONFIG.defaultWebAppOrigin
      ? CART_IT_CONFIG.defaultWebAppOrigin
      : "https://cart-it.com";
  const { webAppOrigin: stored } = await chrome.storage.local.get(["webAppOrigin"]);
  const raw = String(stored || fallback).trim().replace(/\/$/, "");
  return raw || fallback.replace(/\/$/, "");
}

function setStatus(text, ok) {
  const el = document.getElementById("status");
  if (!el) return;
  if (!text) {
    el.className = "";
    el.textContent = "";
    el.classList.remove("active");
    return;
  }
  el.textContent = text;
  el.className = ok ? "ok active" : "err active";
}

function setWishlistLink(href) {
  const el = document.getElementById("viewWishlistLink");
  const row = document.getElementById("afterSaveActions");
  if (!el) return;
  if (!href) {
    el.removeAttribute("href");
    if (row) row.hidden = true;
    return;
  }
  el.href = href;
  if (row) row.hidden = false;
}

function setTabHint(text) {
  const el = document.getElementById("tabHint");
  if (el) el.textContent = text || "";
}

function setPriceHint(text, ok = true) {
  const el = document.getElementById("priceHint");
  if (!el) return;
  el.textContent = text || "";
  el.style.color = ok ? "#166534" : "#991b1b";
}

function setCapturePreview(result) {
  const wrap = document.getElementById("capturePreview");
  const imgEl = document.getElementById("capturePreviewImg");
  const descEl = document.getElementById("capturePreviewDesc");
  if (!wrap || !imgEl || !descEl) return;
  const img = (result?.image_url && String(result.image_url).trim()) || "";
  const desc = (result?.product_description && String(result.product_description).trim()) || "";
  if (!img && !desc) {
    wrap.hidden = true;
    imgEl.removeAttribute("src");
    descEl.textContent = "";
    return;
  }
  wrap.hidden = false;
  if (img) {
    imgEl.hidden = false;
    imgEl.src = img;
    imgEl.referrerPolicy = "no-referrer";
    imgEl.onerror = () => {
      imgEl.hidden = true;
    };
  } else {
    imgEl.hidden = true;
    imgEl.removeAttribute("src");
  }
  if (desc) {
    descEl.hidden = false;
    descEl.textContent = desc.length > 220 ? `${desc.slice(0, 217)}…` : desc;
  } else {
    descEl.hidden = true;
    descEl.textContent = "";
  }
}

async function resolveJwt() {
  await requestTokenSyncFromBackground();
  await syncTokenFromOpenTabs();
  const { jwt } = await chrome.storage.local.get(["jwt"]);
  const tok = isLikelyJwt(jwt) ? jwt : "";
  if (tok) authRejected = false;
  return tok;
}

async function setAuthLine() {
  const el = document.getElementById("authStatus");
  const userBanner = document.getElementById("signedInUser");
  const avatar = document.getElementById("userAvatar");
  const signInWrap = document.getElementById("signInWrap");
  const syncBtn = document.getElementById("syncSessionBtn");
  const signOutBtn = document.getElementById("signOutBtn");

  const jwt = await resolveJwt();
  const ok = !!jwt;

  if (ok && !currentUserLabel) {
    try {
      const base = await apiBase();
      const meRes = await fetch(`${base}/api/me`, {
        headers: { Authorization: `Bearer ${jwt}` },
      });
      const meData = await meRes.json().catch(() => null);
      if (meRes.ok) {
        currentUserLabel = String(meData?.user?.username || meData?.user?.email || "");
      }
    } catch { /* ignore */ }
  }

  if (el) {
    el.textContent = ok
      ? "You're signed in. Save items from any product page."
      : "Leave cart-it.com open while logged in, then tap Sync login.";
  }

  if (userBanner) userBanner.textContent = ok && currentUserLabel ? currentUserLabel : "Not signed in";
  if (avatar && ok && currentUserLabel) avatar.textContent = currentUserLabel.charAt(0).toUpperCase();
  
  if (signInWrap) signInWrap.hidden = ok;
  if (syncBtn) syncBtn.hidden = ok;
  if (signOutBtn) signOutBtn.hidden = !ok;
}

function isLikelyJwt(token) {
  return typeof token === "string" && token.split(".").length === 3 && token.length > 20;
}

function isCartItHost(hostname) {
  const fn = globalThis.CART_IT_CONFIG?.isWebAppHost;
  if (typeof fn === "function") return fn(hostname);
  return hostname === "localhost" || hostname === "127.0.0.1" || hostname.includes("cart-it");
}

async function readTokenFromTab(tabId) {
  const readFunc = () => {
    try {
      const t = localStorage.getItem("token");
      return typeof t === "string" ? t : "";
    } catch {
      return "";
    }
  };
  let raw = "";
  try {
    const inj = await chrome.scripting.executeScript({
      target: { tabId },
      func: readFunc,
    });
    raw = inj?.[0]?.result ?? "";
  } catch { /* no access */ }
  
  let tok = normalizePanelToken(raw);
  if (isLikelyJwt(tok)) return tok;
  
  try {
    const inj = await chrome.scripting.executeScript({
      target: { tabId },
      world: "MAIN",
      func: readFunc,
    });
    raw = inj?.[0]?.result ?? "";
  } catch { /* MAIN unsupported */ }
  return normalizePanelToken(raw);
}

function normalizePanelToken(raw) {
  let t = typeof raw === "string" ? raw.trim() : "";
  if (t.startsWith("Bearer ")) t = t.slice(7).trim();
  return t;
}

function requestTokenSyncFromBackground() {
  return new Promise((resolve) => {
    try {
      chrome.runtime.sendMessage({ type: "REQUEST_TOKEN_SYNC" }, (r) => {
        void chrome.runtime.lastError;
        resolve(r && r.ok === true);
      });
    } catch {
      resolve(false);
    }
  });
}

async function syncTokenFromOpenTabs() {
  const tabs = await chrome.tabs.query({});
  const localTabs = tabs.filter((tab) => {
    if (!tab?.id || !tab.url) return false;
    try {
      const u = new URL(tab.url);
      return isCartItHost(u.hostname);
    } catch { return false; }
  });

  for (const tab of localTabs) {
    try {
      const clean = await readTokenFromTab(tab.id);
      if (isLikelyJwt(clean)) {
        const origin = new URL(tab.url).origin;
        await chrome.storage.local.set({ jwt: clean, jwt_origin: origin });
        return true;
      }
    } catch { /* ignore */ }
  }
  return false;
}

async function apiBase() {
  const { apiBase: raw } = await chrome.storage.local.get(["apiBase"]);
  return (raw || DEFAULT_API).replace(/\/$/, "");
}

async function refreshFromTab() {
  try {
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    if (!tab?.id) {
      lastCapture = null;
      setTabHint("");
      return false;
    }

    const manualPriceEl = document.getElementById("manualPrice");
    if (manualPriceEl) {
      manualPriceEl.addEventListener("input", () => {
        manualPriceDirty = true;
      });

      if (!manualPriceDirty) {
        manualPriceEl.placeholder = "Detecting price...";
        manualPriceEl.value = "";
      }
    }
    setPriceHint("Detecting price from page...", true);

    const inj = await chrome.scripting.executeScript({
      target: { tabId: tab.id },
      func: getPageData,
    });
    const result = inj?.[0]?.result;
    if (!result) {
      if (manualPriceEl) manualPriceEl.placeholder = "Price not found";
      setPriceHint("Price not found. Please enter manually.", false);
      return false;
    }
    
    lastCapture = result;
    setCapturePreview(result);
    
    if (manualPriceEl && (!manualPriceDirty || manualPriceEl.value === "")) {
      if (result.current_price > 0) {
        manualPriceEl.value = String(result.current_price);
        manualPriceEl.placeholder = "";
      } else {
        manualPriceEl.placeholder = "Enter price";
      }
    }
    
    if (Number(result?.current_price || 0) > 0) {
      setPriceHint(`Auto price: $${Number(result.current_price).toFixed(2)}`, true);
    } else {
      setPriceHint("Price not found. Please enter manually.", false);
    }
    
    const title = (result.item_name || "").trim();
    setTabHint(title ? `From: ${truncate(title, 50)}` : "Ready to save.");
    return true;
  } catch (e) {
    lastCapture = null;
    setCapturePreview(null);
    setTabHint("");
    return false;
  }
}

async function loadCategories() {
  const jwt = await resolveJwt();
  const base = await apiBase();
  const sel = document.getElementById("category");
  if (!sel) return;
  
  if (!jwt) {
    sel.innerHTML = '<option value="">No category</option>';
    return;
  }
  
  try {
    const res = await fetch(`${base}/api/groups`, {
      headers: { Authorization: `Bearer ${jwt}` },
    });
    const data = await res.json().catch(() => null);
    if (!res.ok) return;
    
    cachedGroups = Array.isArray(data) ? data : [];
    renderCategoryOptions();
  } catch { /* ignore */ }
}

function renderCategoryOptions() {
  const sel = document.getElementById("category");
  const scopeEl = document.getElementById("listScope");
  if (!sel) return;
  
  const prev = sel.value;
  const scope = scopeEl?.value || "Private";
  sel.innerHTML = '<option value="">No category</option>';
  
  const filtered = cachedGroups.filter((g) => String(g.visibility || "Private") === scope);
  for (const g of filtered) {
    const opt = document.createElement("option");
    opt.value = String(g.group_id);
    opt.textContent = g.group_name || `Category ${g.group_id}`;
    sel.appendChild(opt);
  }
  if (prev && [...sel.options].some((o) => o.value === prev)) sel.value = prev;
}

async function loadWishlistItems() {
  const container = document.getElementById("wishlistItemsContainer");
  if (!container) return;
  
  const jwt = await resolveJwt();
  const base = await apiBase();
  
  if (!jwt) {
    container.innerHTML = '<div class="empty-state"><p>Sign in to view your items.</p></div>';
    return;
  }
  
  container.innerHTML = '<div class="empty-state"><p>Loading items...</p></div>';
  
  try {
    const gidRaw = document.getElementById("category").value;
    const url = gidRaw ? `${base}/api/cart-items?group_id=${gidRaw}` : `${base}/api/cart-items`;
    
    const res = await fetch(url, {
      headers: { Authorization: `Bearer ${jwt}` },
    });
    const items = await res.json();
    
    if (!res.ok || !Array.isArray(items) || items.length === 0) {
      container.innerHTML = '<div class="empty-state"><p>No items found in this category.</p></div>';
      return;
    }
    
    container.innerHTML = "";
    items.forEach((item) => {
      const el = document.createElement("div");
      el.className = "wishlist-item";
      el.innerHTML = `
        <img src="${item.image_url || 'icon.png'}" onerror="this.src='icon.png'" />
        <div class="wishlist-item-info">
          <p class="wishlist-item-name">${truncate(item.item_name, 40)}</p>
          <p class="wishlist-item-price">$${Number(item.current_price || 0).toFixed(2)}</p>
          <div class="wishlist-item-actions">
            <button class="action-icon-btn open-btn" title="Open product">🔗</button>
            <button class="action-icon-btn delete-btn" title="Delete">🗑️</button>
          </div>
        </div>
      `;
      el.querySelector(".open-btn").addEventListener("click", () => chrome.tabs.create({ url: item.product_url }));
      el.querySelector(".delete-btn").addEventListener("click", async () => {
        if (!confirm("Delete this item?")) return;
        await fetch(`${base}/api/cart-items/${item.item_id}`, {
          method: "DELETE",
          headers: { Authorization: `Bearer ${jwt}` },
        });
        loadWishlistItems();
      });
      container.appendChild(el);
    });
  } catch (e) {
    container.innerHTML = '<div class="empty-state"><p>Error loading items.</p></div>';
  }
}

// Tab Switching
document.querySelectorAll(".tab-btn").forEach((btn) => {
  btn.addEventListener("click", () => {
    document.querySelectorAll(".tab-btn").forEach((b) => b.classList.remove("active"));
    document.querySelectorAll(".tab-panel").forEach((p) => p.classList.remove("active"));
    
    btn.classList.add("active");
    const panelId = `${btn.dataset.tab}Panel`;
    document.getElementById(panelId).classList.add("active");
    
    if (btn.dataset.tab === "wishlist") loadWishlistItems();
    if (btn.dataset.tab === "account") setAuthLine();
  });
});

document.getElementById("toggleNewCat")?.addEventListener("click", () => {
  const wrap = document.getElementById("newCatWrap");
  if (wrap) wrap.hidden = !wrap.hidden;
});

document.getElementById("createCatBtn")?.addEventListener("click", async () => {
  const name = document.getElementById("newCatName").value.trim();
  if (!name) return setStatus("Enter a name.", false);
  
  const jwt = await resolveJwt();
  const base = await apiBase();
  const visibility = document.getElementById("listScope").value;
  
  try {
    const res = await fetch(`${base}/api/groups`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${jwt}`,
      },
      body: JSON.stringify({ group_name: name, visibility }),
    });
    if (res.ok) {
      const data = await res.json();
      document.getElementById("newCatName").value = "";
      document.getElementById("newCatWrap").hidden = true;
      await loadCategories();
      document.getElementById("category").value = String(data.group.group_id);
      setStatus("Category created!", true);
    }
  } catch (e) { setStatus("Error creating category.", false); }
});

document.getElementById("saveBtn")?.addEventListener("click", async () => {
  const btn = document.getElementById("saveBtn");
  btn.disabled = true;
  setStatus("Saving...", true);
  
  try {
    const jwt = await resolveJwt();
    if (!jwt) return setStatus("Please sign in first.", false);
    
    await refreshFromTab();
    const cap = lastCapture;
    const [activeTab] = await chrome.tabs.query({ active: true, currentWindow: true });
    
    const product_url = cap?.product_url || activeTab?.url;
    const item_name = cap?.item_name || activeTab?.title || "New Item";
    const manualPriceVal = document.getElementById("manualPrice").value;
    const current_price = manualPriceVal !== "" ? parseFloat(manualPriceVal) : (cap?.current_price || 0);
    
    const body = {
      item_name,
      product_url,
      current_price,
      image_url: cap?.image_url,
      store: cap?.store,
      notes: document.getElementById("notes").value,
      group_id: document.getElementById("category").value || null,
    };
    
    const base = await apiBase();
    const res = await fetch(`${base}/api/cart-items`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${jwt}`,
      },
      body: JSON.stringify(body),
    });
    
    if (res.ok) {
      const data = await res.json();
      setStatus("Saved successfully!", true);
      const webBase = await getWebAppOrigin();
      const itemUrl = `${webBase}/item/${data.item_id}`;
      
      const wishlistLink = document.getElementById("viewWishlistLink");
      if (wishlistLink) {
        wishlistLink.href = itemUrl;
        wishlistLink.onclick = (e) => {
          e.preventDefault();
          chrome.tabs.create({ url: itemUrl });
        };
      }

      const saveDashLink = document.getElementById("saveTabDashboardLink");
      if (saveDashLink) {
        saveDashLink.href = `${webBase}/dashboard`;
        saveDashLink.onclick = (e) => {
          e.preventDefault();
          chrome.tabs.create({ url: `${webBase}/dashboard` });
        };
      }

      setWishlistLink(itemUrl);
    } else {
      const err = await res.json();
      setStatus(err.message || "Save failed.", false);
    }
  } catch (e) { setStatus("Network error.", false); }
  finally { btn.disabled = false; }
});

document.getElementById("reScrapeBtn")?.addEventListener("click", () => {
  setStatus("Refreshing page data...", true);
  refreshFromTab().then(() => setStatus("Refreshed.", true));
});

document.getElementById("aiSummarizeBtn")?.addEventListener("click", async () => {
  if (!lastCapture) return setStatus("No product data captured yet.", false);
  
  const jwt = await resolveJwt();
  const base = await apiBase();
  if (!jwt) return setStatus("Please sign in to use AI features.", false);
  
  setStatus("AI is summarizing...", true);
  try {
    const res = await fetch(`${base}/api/ai/summarize`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${jwt}`,
      },
      body: JSON.stringify({
        item_name: lastCapture.item_name,
        product_description: lastCapture.product_description,
        store: lastCapture.store,
      }),
    });
    const data = await res.json();
    if (res.ok && data.summary) {
      document.getElementById("notes").value = data.summary;
      setStatus("Summary added to notes!", true);
    } else {
      setStatus(data.message || "AI summary failed.", false);
    }
  } catch (e) { setStatus("Error connecting to AI service.", false); }
});

document.getElementById("goToDashboardBtn")?.addEventListener("click", async () => {
  const origin = await getWebAppOrigin();
  chrome.tabs.create({ url: `${origin}/dashboard` });
});

document.getElementById("signOutBtn")?.addEventListener("click", async () => {
  await chrome.storage.local.remove(["jwt", "jwt_origin"]);
  currentUserLabel = "";
  await setAuthLine();
  await loadCategories();
  setStatus("Signed out.", true);
});

document.getElementById("signInBtn")?.addEventListener("click", async () => {
  const email = document.getElementById("signInEmail").value.trim();
  const password = document.getElementById("signInPassword").value;
  if (!email || !password) return setStatus("Enter email and password.", false);
  
  const base = await apiBase();
  try {
    const res = await fetch(`${base}/api/login`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ email, password }),
    });
    const data = await res.json();
    if (res.ok) {
      await chrome.storage.local.set({ jwt: data.token });
      currentUserLabel = data.user?.username || data.user?.email || "";
      await setAuthLine();
      await loadCategories();
      setStatus("Signed in!", true);
    } else {
      setStatus(data.message || "Sign in failed.", false);
    }
  } catch (e) { setStatus("Network error.", false); }
});

document.getElementById("createAccountBtn")?.addEventListener("click", async () => {
  const origin = await getWebAppOrigin();
  chrome.tabs.create({ url: `${origin}/signup` });
});

document.getElementById("syncSessionBtn")?.addEventListener("click", async () => {
  setStatus("Syncing...", true);
  await syncTokenFromOpenTabs();
  await setAuthLine();
  await loadCategories();
  setStatus("Synced!", true);
});

document.getElementById("listScope")?.addEventListener("change", renderCategoryOptions);
document.getElementById("category")?.addEventListener("change", () => {
  if (document.querySelector(".tab-btn[data-tab='wishlist']").classList.contains("active")) {
    loadWishlistItems();
  }
});

document.getElementById("closePanelBtn")?.addEventListener("click", () => {
  window.close();
});

// Initialization
async function init() {
  await setAuthLine();
  await loadCategories();
  await refreshFromTab();
}

init();
